from setuptools import setup

setup(name='custom_transforms', version='0.1', scripts=['custom_transforms.py', 'predictor.py'])